package com.example.systemproject.notificationsapp;

import android.app.Application;
import android.app.NotificationChannel;
import android.app.NotificationManager;
import android.os.Build;
    
public class GetChannalJavaClass extends Application {

    public static final String CHANNEL_1_ID = "chennal1";
    public static final String CHENNEL_2_ID = "Channal2";

    @Override
    public void onCreate() {
        super.onCreate();

        createNotificationchannels();
    }
    public void createNotificationchannels(){
        if (Build.VERSION.SDK_INT >= Build.VERSION_CODES.O){
            NotificationChannel notificationChannel = new NotificationChannel(
                    CHANNEL_1_ID,
                    "channel1",
                    NotificationManager.IMPORTANCE_HIGH
            );
            notificationChannel.setDescription("this is chennel 1");

            NotificationManager manager = getSystemService(NotificationManager.class);
            manager.createNotificationChannel(notificationChannel);

        }
    }
}
